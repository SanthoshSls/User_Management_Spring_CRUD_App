
export interface User {
    id: number
    name: string
    gender: string
    dob: string
    email: string
    pNo: string
    address: string
}